# -*- coding: utf-8 -*-
from pathlib import Path
import json

root_dir = Path("/content/drive/My Drive/imcg/imcg21a")


def loadUserProfile():
    if not root_dir.exists():
        root_dir.mkdir(parents=True)

    with open(str(root_dir/'user.json'), mode='rt', encoding='utf-8') as file:
        data = json.load(file)
    return data


class UserData:
    def __init__(self):
        self._data = loadUserProfile()
        self.user_id = self._data["user_id"]
        self.user_name = self._data["user_name"]
        self.user_dir = root_dir / "users" / self.user_id


def loadUserInfo():
    user_data = UserData()
    return user_data
